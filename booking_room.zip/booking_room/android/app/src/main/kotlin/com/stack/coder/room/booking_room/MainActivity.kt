package com.stack.coder.room.booking_room

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
