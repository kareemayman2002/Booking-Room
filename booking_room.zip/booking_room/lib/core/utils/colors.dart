import 'package:flutter/material.dart';

abstract class AppColors{
 static  const Color primaryColor = Color(0xFF20473E);
 static  const  Color secondaryColor = Color(0xff20473E);
 static const Color tertiaryColor = Color(0xFF087C7C);
 static const Color textColor = Color(0xFF4D5454);
}